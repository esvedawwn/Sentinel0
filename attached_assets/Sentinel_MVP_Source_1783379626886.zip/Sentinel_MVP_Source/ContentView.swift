import SwiftUI

struct ContentView: View {

    @StateObject private var sentinel = SentinelManager()
    @State private var selectedSection: SentinelSection = .home

    var body: some View {
        NavigationSplitView {
            SidebarView(selectedSection: $selectedSection)
        } detail: {
            detailView
                .environmentObject(sentinel)
        }
        .environmentObject(sentinel)
        .background(SentinelTheme.Colors.background)
    }

    @ViewBuilder
    private var detailView: some View {
        switch selectedSection {
        case .home:
            DashboardView()
        case .observe:
            FindingsView(title: "Observe", riskFilter: nil)
        case .organise:
            FindingsView(title: "Organise", riskFilter: .safeDelete)
        case .projects:
            PlaceholderView(title: "Projects", message: "Project intelligence will connect related design, legal, renovation and business files.")
        case .intelligence:
            PlaceholderView(title: "Intelligence", message: "OCR, semantic search and AI classification will live here.")
        case .reports:
            ReportsView()
        case .settings:
            SettingsView()
        }
    }
}

#Preview {
    ContentView()
}
