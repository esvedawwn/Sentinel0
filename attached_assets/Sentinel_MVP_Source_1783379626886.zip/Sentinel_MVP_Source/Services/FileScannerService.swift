import Foundation

struct ScanProgressUpdate {
    let filesScanned: Int
    let foldersScanned: Int
    let bytesScanned: Int64
    let progress: Double
    let currentPath: String
}

final class FileScannerService {

    private let fileManager = FileManager.default

    private let skipFolderNames: Set<String> = [
        "Library", "Applications", "System", "Volumes", "Network",
        "node_modules", ".git", ".Trash", "Sorted", "__pycache__"
    ]

    private let packageExtensions: Set<String> = [
        "app", "framework", "bundle", "plugin", "kext", "pkg", "xcodeproj", "xcworkspace"
    ]

    func scan(
        roots: [URL],
        onProgress: @MainActor @escaping (ScanProgressUpdate) -> Void,
        onFinding: @MainActor @escaping (ScanFinding) -> Void
    ) async throws {

        var filesScanned = 0
        var foldersScanned = 0
        var bytesScanned: Int64 = 0
        var estimatedTotal = max(roots.count * 1200, 1)

        for root in roots {
            try Task.checkCancellation()

            guard fileManager.fileExists(atPath: root.path) else { continue }

            let enumerator = fileManager.enumerator(
                at: root,
                includingPropertiesForKeys: [.isDirectoryKey, .fileSizeKey],
                options: [.skipsHiddenFiles, .skipsPackageDescendants],
                errorHandler: { _, _ in true }
            )

            while let item = enumerator?.nextObject() as? URL {
                try Task.checkCancellation()

                if shouldSkip(item) {
                    enumerator?.skipDescendants()
                    continue
                }

                let values = try? item.resourceValues(forKeys: [.isDirectoryKey, .fileSizeKey])
                let isDirectory = values?.isDirectory ?? false
                let size = Int64(values?.fileSize ?? 0)

                if isDirectory {
                    foldersScanned += 1

                    if isEffectivelyEmptyFolder(item) {
                        await onFinding(
                            ScanFinding(
                                path: item.path,
                                name: item.lastPathComponent,
                                category: .emptyFolder,
                                risk: .safeDelete,
                                size: 0,
                                reason: "Folder appears empty or contains only hidden metadata."
                            )
                        )
                    }
                } else {
                    filesScanned += 1
                    bytesScanned += size

                    if let finding = classifyFile(item, size: size) {
                        await onFinding(finding)
                    }
                }

                let scannedTotal = filesScanned + foldersScanned
                if scannedTotal > estimatedTotal {
                    estimatedTotal = scannedTotal + 1000
                }

                if scannedTotal % 50 == 0 {
                    let progress = min(Double(scannedTotal) / Double(estimatedTotal), 0.98)
                    await onProgress(
                        ScanProgressUpdate(
                            filesScanned: filesScanned,
                            foldersScanned: foldersScanned,
                            bytesScanned: bytesScanned,
                            progress: progress,
                            currentPath: item.path
                        )
                    )
                }
            }
        }

        await onProgress(
            ScanProgressUpdate(
                filesScanned: filesScanned,
                foldersScanned: foldersScanned,
                bytesScanned: bytesScanned,
                progress: 1,
                currentPath: "Complete"
            )
        )
    }

    private func shouldSkip(_ url: URL) -> Bool {
        if url.pathComponents.contains(where: { skipFolderNames.contains($0) }) {
            return true
        }

        if url.pathComponents.contains(where: { $0.hasPrefix(".") }) {
            return true
        }

        if packageExtensions.contains(url.pathExtension.lowercased()) {
            return true
        }

        return false
    }

    private func isEffectivelyEmptyFolder(_ url: URL) -> Bool {
        do {
            let contents = try fileManager.contentsOfDirectory(
                at: url,
                includingPropertiesForKeys: nil,
                options: [.skipsHiddenFiles]
            )
            return contents.isEmpty
        } catch {
            return false
        }
    }

    private func classifyFile(_ url: URL, size: Int64) -> ScanFinding? {
        let name = url.lastPathComponent
        let lower = name.lowercased()
        let ext = url.pathExtension.lowercased()

        if lower.hasSuffix(".idlk") {
            return ScanFinding(path: url.path, name: name, category: .adobeLock, risk: .safeDelete, size: size, reason: "Adobe InDesign lock file. Safe if Adobe apps are closed.")
        }

        if lower.hasSuffix(".locked") {
            return ScanFinding(path: url.path, name: name, category: .googleLock, risk: .safeDelete, size: size, reason: "Stale Google/Chrome/Drive lock file.")
        }

        if size == 0 {
            return ScanFinding(path: url.path, name: name, category: .zeroByteFile, risk: .review, size: size, reason: "Empty file. Review before deleting unless it is clearly junk.")
        }

        if ["dmg", "pkg", "zip", "rar", "7z", "iso"].contains(ext) {
            return ScanFinding(path: url.path, name: name, category: .installer, risk: .review, size: size, reason: "Installer or archive. May be removable if no longer needed.")
        }

        if size > 500_000_000 {
            return ScanFinding(path: url.path, name: name, category: .largeFile, risk: .review, size: size, reason: "Large file over 500 MB.")
        }

        return nil
    }
}
