import Foundation
import Combine
import AppKit

@MainActor
final class SentinelManager: ObservableObject {

    @Published var state: ScanState = .ready
    @Published var activities: [ActivityItem] = []
    @Published var findings: [ScanFinding] = []
    @Published var selectedRoots: [URL] = []
    @Published var indexedFiles = 0
    @Published var indexedFolders = 0
    @Published var bytesScanned: Int64 = 0
    @Published var scanProgress: Double = 0
    @Published var currentPath = "Waiting..."

    private var scanTask: Task<Void, Never>?

    init() {
        selectedRoots = defaultScanRoots()
        log("Sentinel ready.", category: .success)
    }

    var latestActivity: String {
        activities.first?.message ?? "Waiting..."
    }

    var safeDeleteCount: Int {
        findings.filter { $0.risk == .safeDelete }.count
    }

    var reviewCount: Int {
        findings.filter { $0.risk == .review }.count
    }

    var statusText: String {
        switch state {
        case .ready: return "READY"
        case .scanning: return "SCANNING"
        case .analysing: return "ANALYSING"
        case .complete: return "COMPLETE"
        case .error: return "ERROR"
        }
    }

    func defaultScanRoots() -> [URL] {
        let home = FileManager.default.homeDirectoryForCurrentUser
        let candidates = [
            home.appendingPathComponent("Desktop"),
            home.appendingPathComponent("Documents"),
            home.appendingPathComponent("Downloads"),
            home.appendingPathComponent("Library/Mobile Documents/com~apple~CloudDocs")
        ]
        return candidates.filter { FileManager.default.fileExists(atPath: $0.path) }
    }

    func chooseFolders() {
        let panel = NSOpenPanel()
        panel.message = "Choose folders for Sentinel to scan."
        panel.prompt = "Add Folders"
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = true

        if panel.runModal() == .OK {
            selectedRoots = panel.urls
            log("Selected \(panel.urls.count) folder(s).", category: .success)
        }
    }

    func resetDefaultFolders() {
        selectedRoots = defaultScanRoots()
        log("Default folders restored.", category: .info)
    }

    func startScan() {
        scanTask?.cancel()

        state = .scanning
        activities.removeAll()
        findings.removeAll()
        indexedFiles = 0
        indexedFolders = 0
        bytesScanned = 0
        scanProgress = 0
        currentPath = "Preparing..."

        log("Preparing scan...", category: .scan)
        log("Scanning \(selectedRoots.count) root folder(s).", category: .info)

        let roots = selectedRoots

        scanTask = Task {
            do {
                let scanner = FileScannerService()

                try await scanner.scan(
                    roots: roots,
                    onProgress: { [weak self] update in
                        guard let self else { return }
                        self.indexedFiles = update.filesScanned
                        self.indexedFolders = update.foldersScanned
                        self.bytesScanned = update.bytesScanned
                        self.scanProgress = update.progress
                        self.currentPath = update.currentPath

                        if update.filesScanned % 250 == 0 {
                            self.log("Indexed \(update.filesScanned) files.", category: .scan)
                        }
                    },
                    onFinding: { [weak self] finding in
                        guard let self else { return }
                        self.findings.append(finding)

                        if finding.risk != .keep {
                            self.log("\(finding.category.rawValue): \(finding.name)", category: finding.risk == .safeDelete ? .success : .warning)
                        }
                    }
                )

                state = .complete
                scanProgress = 1
                currentPath = "Scan complete."
                log("Scan complete. \(indexedFiles) files scanned.", category: .success)

            } catch {
                state = .error
                currentPath = "Scan failed."
                log("Scan failed: \(error.localizedDescription)", category: .error)
            }
        }
    }

    func cancelScan() {
        scanTask?.cancel()
        scanTask = nil
        state = .ready
        currentPath = "Cancelled."
        log("Scan cancelled.", category: .warning)
    }

    func log(_ message: String, category: ActivityItem.Category = .info) {
        activities.insert(ActivityItem(timestamp: Date(), message: message, category: category), at: 0)

        if activities.count > 250 {
            activities.removeLast()
        }
    }
}
