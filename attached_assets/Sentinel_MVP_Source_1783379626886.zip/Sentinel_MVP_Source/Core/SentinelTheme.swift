import SwiftUI

enum SentinelTheme {
    enum Colors {
        static let background = Color(hex: "111111")
        static let panel = Color(hex: "1A1A1A")
        static let card = Color(hex: "222222")
        static let cardAlt = Color(hex: "191919")

        static let primaryText = Color.white
        static let secondaryText = Color.white.opacity(0.58)
        static let tertiaryText = Color.white.opacity(0.35)

        static let ready = Color(hex: "34D399")
        static let review = Color(hex: "FBBF24")
        static let actionRequired = Color(hex: "F87171")
        static let inProgress = Color(hex: "60A5FA")
        static let lilac = Color(hex: "C4B5FD")
    }

    enum Typography {
        static let pageTitle = Font.system(size: 34, weight: .bold, design: .default)
        static let sectionLabel = Font.system(size: 11, weight: .semibold, design: .monospaced)
        static let metric = Font.system(size: 34, weight: .bold, design: .monospaced)
        static let body = Font.system(size: 14, weight: .regular, design: .default)
        static let data = Font.system(size: 13, weight: .regular, design: .monospaced)
        static let smallData = Font.system(size: 11, weight: .regular, design: .monospaced)
    }

    enum Spacing {
        static let xs: CGFloat = 4
        static let sm: CGFloat = 8
        static let md: CGFloat = 16
        static let lg: CGFloat = 24
        static let xl: CGFloat = 32
    }
}
