import SwiftUI

struct ReportsView: View {

    @EnvironmentObject var sentinel: SentinelManager

    var body: some View {
        VStack(alignment: .leading, spacing: SentinelTheme.Spacing.lg) {
            Text("REPORTS")
                .font(SentinelTheme.Typography.pageTitle)
                .foregroundStyle(SentinelTheme.Colors.primaryText)

            Text("CURRENT SCAN SUMMARY")
                .font(SentinelTheme.Typography.sectionLabel)
                .foregroundStyle(SentinelTheme.Colors.ready)

            VStack(alignment: .leading, spacing: SentinelTheme.Spacing.sm) {
                Text("Files scanned: \(sentinel.indexedFiles)")
                Text("Folders scanned: \(sentinel.indexedFolders)")
                Text("Data scanned: \(sentinel.bytesScanned.sentinelByteString)")
                Text("Safe delete candidates: \(sentinel.safeDeleteCount)")
                Text("Review candidates: \(sentinel.reviewCount)")
                Text("Total findings: \(sentinel.findings.count)")
            }
            .font(SentinelTheme.Typography.data)
            .foregroundStyle(SentinelTheme.Colors.primaryText)
            .padding()
            .background(SentinelTheme.Colors.panel)

            ActivityLogView()

            Spacer()
        }
        .padding(SentinelTheme.Spacing.xl)
        .background(SentinelTheme.Colors.background)
    }
}
