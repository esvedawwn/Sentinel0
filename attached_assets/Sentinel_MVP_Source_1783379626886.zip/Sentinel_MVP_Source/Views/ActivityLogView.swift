import SwiftUI

struct ActivityLogView: View {

    @EnvironmentObject var sentinel: SentinelManager

    private let formatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        return formatter
    }()

    var body: some View {
        VStack(alignment: .leading, spacing: SentinelTheme.Spacing.md) {
            HStack {
                Text("RECENT ACTIVITY")
                    .font(SentinelTheme.Typography.sectionLabel)
                    .foregroundStyle(SentinelTheme.Colors.ready)

                Spacer()

                Text("\(sentinel.activities.count) EVENTS")
                    .font(SentinelTheme.Typography.smallData)
                    .foregroundStyle(SentinelTheme.Colors.secondaryText)
            }

            VStack(spacing: 6) {
                ForEach(sentinel.activities.prefix(12)) { item in
                    HStack(alignment: .top, spacing: 10) {
                        Text(formatter.string(from: item.timestamp))
                            .font(SentinelTheme.Typography.smallData)
                            .foregroundStyle(SentinelTheme.Colors.tertiaryText)
                            .frame(width: 62, alignment: .leading)

                        Text(item.category.symbol)
                            .font(SentinelTheme.Typography.data)
                            .foregroundStyle(colour(for: item.category))
                            .frame(width: 18)

                        Text(item.message)
                            .font(SentinelTheme.Typography.data)
                            .foregroundStyle(SentinelTheme.Colors.primaryText)
                            .lineLimit(1)

                        Spacer()
                    }
                }

                if sentinel.activities.isEmpty {
                    Text("No activity yet.")
                        .font(SentinelTheme.Typography.data)
                        .foregroundStyle(SentinelTheme.Colors.secondaryText)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
        }
        .padding(SentinelTheme.Spacing.lg)
        .background(SentinelTheme.Colors.panel)
        .overlay(Rectangle().stroke(SentinelTheme.Colors.ready.opacity(0.35), lineWidth: 1))
    }

    private func colour(for category: ActivityItem.Category) -> Color {
        switch category {
        case .info: return SentinelTheme.Colors.secondaryText
        case .success: return SentinelTheme.Colors.ready
        case .warning: return SentinelTheme.Colors.review
        case .error: return SentinelTheme.Colors.actionRequired
        case .scan: return SentinelTheme.Colors.inProgress
        }
    }
}
