import SwiftUI

struct FindingsView: View {

    @EnvironmentObject var sentinel: SentinelManager

    let title: String
    let riskFilter: FindingRisk?

    private var filteredFindings: [ScanFinding] {
        if let riskFilter {
            return sentinel.findings.filter { $0.risk == riskFilter }
        }
        return sentinel.findings
    }

    var body: some View {
        VStack(alignment: .leading, spacing: SentinelTheme.Spacing.lg) {
            HStack {
                VStack(alignment: .leading) {
                    Text(title.uppercased())
                        .font(SentinelTheme.Typography.pageTitle)
                        .foregroundStyle(SentinelTheme.Colors.primaryText)

                    Text("\(filteredFindings.count) findings")
                        .font(SentinelTheme.Typography.data)
                        .foregroundStyle(SentinelTheme.Colors.secondaryText)
                }

                Spacer()

                Button("Start Scan") {
                    sentinel.startScan()
                }
                .buttonStyle(.borderedProminent)
                .tint(SentinelTheme.Colors.ready)
            }

            Table(filteredFindings) {
                TableColumn("Risk") { finding in
                    Text(finding.risk.rawValue).foregroundStyle(colour(for: finding.risk))
                }
                TableColumn("Category") { finding in Text(finding.category.rawValue) }
                TableColumn("Name") { finding in Text(finding.name) }
                TableColumn("Size") { finding in Text(finding.size.sentinelByteString).font(SentinelTheme.Typography.data) }
                TableColumn("Reason") { finding in Text(finding.reason) }
                TableColumn("Path") { finding in
                    Text(finding.path)
                        .font(SentinelTheme.Typography.smallData)
                        .foregroundStyle(.secondary)
                }
            }
            .scrollContentBackground(.hidden)

            Text("MVP is preview-only. No files are deleted or moved.")
                .font(SentinelTheme.Typography.data)
                .foregroundStyle(SentinelTheme.Colors.review)
        }
        .padding(SentinelTheme.Spacing.xl)
        .background(SentinelTheme.Colors.background)
    }

    private func colour(for risk: FindingRisk) -> Color {
        switch risk {
        case .safeDelete: return SentinelTheme.Colors.ready
        case .review: return SentinelTheme.Colors.review
        case .keep: return SentinelTheme.Colors.secondaryText
        }
    }
}
