import SwiftUI

struct SettingsView: View {

    @EnvironmentObject var sentinel: SentinelManager

    var body: some View {
        VStack(alignment: .leading, spacing: SentinelTheme.Spacing.lg) {
            Text("SETTINGS")
                .font(SentinelTheme.Typography.pageTitle)
                .foregroundStyle(SentinelTheme.Colors.primaryText)

            Text("SCAN ROOTS")
                .font(SentinelTheme.Typography.sectionLabel)
                .foregroundStyle(SentinelTheme.Colors.ready)

            VStack(alignment: .leading, spacing: SentinelTheme.Spacing.sm) {
                ForEach(sentinel.selectedRoots, id: \.path) { url in
                    Text(url.path)
                        .font(SentinelTheme.Typography.data)
                        .foregroundStyle(SentinelTheme.Colors.secondaryText)
                }
            }
            .padding()
            .background(SentinelTheme.Colors.panel)

            HStack {
                Button("Choose Folders") { sentinel.chooseFolders() }
                Button("Restore Defaults") { sentinel.resetDefaultFolders() }
            }

            Text("If App Sandbox blocks default folder access during development, choose folders manually or temporarily disable App Sandbox in Signing & Capabilities.")
                .font(SentinelTheme.Typography.data)
                .foregroundStyle(SentinelTheme.Colors.review)

            Spacer()
        }
        .padding(SentinelTheme.Spacing.xl)
        .background(SentinelTheme.Colors.background)
    }
}
