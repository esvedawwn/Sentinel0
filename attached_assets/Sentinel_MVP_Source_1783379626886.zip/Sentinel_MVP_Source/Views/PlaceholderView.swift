import SwiftUI

struct PlaceholderView: View {

    let title: String
    let message: String

    var body: some View {
        VStack(alignment: .leading, spacing: SentinelTheme.Spacing.lg) {
            Text(title.uppercased())
                .font(SentinelTheme.Typography.pageTitle)
                .foregroundStyle(SentinelTheme.Colors.primaryText)

            Text(message)
                .font(SentinelTheme.Typography.body)
                .foregroundStyle(SentinelTheme.Colors.secondaryText)

            Spacer()
        }
        .padding(SentinelTheme.Spacing.xl)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
        .background(SentinelTheme.Colors.background)
    }
}
