import SwiftUI

struct ProgressBarView: View {

    let progress: Double
    let colour: Color

    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .leading) {
                Rectangle().fill(SentinelTheme.Colors.card)
                Rectangle()
                    .fill(colour)
                    .frame(width: max(0, min(geometry.size.width * progress, geometry.size.width)))
                    .animation(.easeOut(duration: 0.2), value: progress)
            }
        }
        .frame(height: 8)
        .overlay(Rectangle().stroke(colour.opacity(0.45), lineWidth: 1))
    }
}
