import SwiftUI

struct DashboardView: View {

    @EnvironmentObject var sentinel: SentinelManager

    private let columns = [
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible())
    ]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: SentinelTheme.Spacing.lg) {
                header

                LazyVGrid(columns: columns, spacing: SentinelTheme.Spacing.md) {
                    StatusCardView(title: "System", value: sentinel.statusText, detail: sentinel.latestActivity, statusColor: scanColour)
                    StatusCardView(title: "Files", value: "\(sentinel.indexedFiles)", detail: "\(sentinel.indexedFolders) folders", statusColor: SentinelTheme.Colors.inProgress)
                    StatusCardView(title: "Storage", value: sentinel.bytesScanned.sentinelByteString, detail: "Scanned volume", statusColor: SentinelTheme.Colors.lilac)
                    StatusCardView(title: "Safe Delete", value: "\(sentinel.safeDeleteCount)", detail: "Preview only", statusColor: SentinelTheme.Colors.ready)
                    StatusCardView(title: "Review", value: "\(sentinel.reviewCount)", detail: "Needs decision", statusColor: SentinelTheme.Colors.review)
                    StatusCardView(title: "Progress", value: "\(Int(sentinel.scanProgress * 100))%", detail: sentinel.currentPath, statusColor: scanColour)
                }

                ProgressBarView(progress: sentinel.scanProgress, colour: scanColour)

                HStack {
                    Button {
                        sentinel.startScan()
                    } label: {
                        Text(sentinel.state == .scanning || sentinel.state == .analysing ? "SCANNING..." : "START SCAN")
                            .font(SentinelTheme.Typography.sectionLabel)
                            .frame(minWidth: 140)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(scanColour)
                    .disabled(sentinel.state == .scanning || sentinel.state == .analysing)

                    Button("CANCEL") {
                        sentinel.cancelScan()
                    }
                    .disabled(!(sentinel.state == .scanning || sentinel.state == .analysing))

                    Button("CHOOSE FOLDERS") {
                        sentinel.chooseFolders()
                    }

                    Spacer()
                }

                ActivityLogView()
            }
            .padding(SentinelTheme.Spacing.xl)
        }
        .background(SentinelTheme.Colors.background)
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: SentinelTheme.Spacing.sm) {
            Text("SENTINEL")
                .font(SentinelTheme.Typography.pageTitle)
                .foregroundStyle(SentinelTheme.Colors.primaryText)

            Text("Digital operating system for file intelligence.")
                .font(SentinelTheme.Typography.body)
                .foregroundStyle(SentinelTheme.Colors.secondaryText)
        }
    }

    private var scanColour: Color {
        switch sentinel.state {
        case .ready: return SentinelTheme.Colors.ready
        case .scanning, .analysing: return SentinelTheme.Colors.inProgress
        case .complete: return SentinelTheme.Colors.ready
        case .error: return SentinelTheme.Colors.actionRequired
        }
    }
}
