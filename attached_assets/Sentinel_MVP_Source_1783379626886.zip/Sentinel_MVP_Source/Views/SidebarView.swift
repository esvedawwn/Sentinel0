import SwiftUI

struct SidebarView: View {

    @Binding var selectedSection: SentinelSection
    @EnvironmentObject var sentinel: SentinelManager

    var body: some View {
        List(selection: $selectedSection) {
            Section("Sentinel") {
                ForEach([SentinelSection.home, .observe, .organise, .projects, .intelligence, .reports]) { section in
                    Label(section.rawValue, systemImage: section.icon)
                        .tag(section)
                }
            }

            Section("System") {
                HStack {
                    Circle()
                        .fill(statusColour)
                        .frame(width: 8, height: 8)

                    Text(sentinel.statusText)
                        .font(SentinelTheme.Typography.smallData)
                }

                Text("\(sentinel.indexedFiles) FILES")
                    .font(SentinelTheme.Typography.smallData)
                    .foregroundStyle(.secondary)
            }

            Section("Tools") {
                Label("Settings", systemImage: SentinelSection.settings.icon)
                    .tag(SentinelSection.settings)
            }
        }
        .navigationTitle("Sentinel")
    }

    private var statusColour: Color {
        switch sentinel.state {
        case .ready, .complete: return SentinelTheme.Colors.ready
        case .scanning, .analysing: return SentinelTheme.Colors.inProgress
        case .error: return SentinelTheme.Colors.actionRequired
        }
    }
}

#Preview {
    SidebarView(selectedSection: .constant(.home))
        .environmentObject(SentinelManager())
}
