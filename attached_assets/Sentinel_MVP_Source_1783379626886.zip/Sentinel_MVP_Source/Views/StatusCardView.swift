import SwiftUI

struct StatusCardView: View {

    let title: String
    let value: String
    let detail: String
    let statusColor: Color

    var body: some View {
        VStack(alignment: .leading, spacing: SentinelTheme.Spacing.md) {
            Text(title.uppercased())
                .font(SentinelTheme.Typography.sectionLabel)
                .foregroundStyle(statusColor)

            Text(value)
                .font(SentinelTheme.Typography.metric)
                .foregroundStyle(SentinelTheme.Colors.primaryText)
                .lineLimit(1)
                .minimumScaleFactor(0.65)

            Text(detail)
                .font(SentinelTheme.Typography.data)
                .foregroundStyle(SentinelTheme.Colors.secondaryText)
                .lineLimit(2)
        }
        .padding(SentinelTheme.Spacing.lg)
        .frame(maxWidth: .infinity, minHeight: 135, alignment: .leading)
        .background(SentinelTheme.Colors.card)
        .overlay(Rectangle().stroke(statusColor.opacity(0.75), lineWidth: 1))
    }
}
