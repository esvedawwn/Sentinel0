import Foundation

extension Int64 {
    var sentinelByteString: String {
        ByteCountFormatter.string(fromByteCount: self, countStyle: .file)
    }
}
