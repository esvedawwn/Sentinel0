import Foundation

enum FindingRisk: String, CaseIterable, Identifiable {
    case safeDelete = "Safe Delete"
    case review = "Review"
    case keep = "Keep"

    var id: String { rawValue }
}
