import Foundation

struct ScanFinding: Identifiable, Hashable {
    let id = UUID()
    let path: String
    let name: String
    let category: FindingCategory
    let risk: FindingRisk
    let size: Int64
    let reason: String

    var url: URL { URL(fileURLWithPath: path) }
}
