import Foundation

enum SentinelSection: String, CaseIterable, Identifiable {
    case home = "Home"
    case observe = "Observe"
    case organise = "Organise"
    case projects = "Projects"
    case intelligence = "Intelligence"
    case reports = "Reports"
    case settings = "Settings"

    var id: String { rawValue }

    var icon: String {
        switch self {
        case .home: return "house.fill"
        case .observe: return "eye"
        case .organise: return "sparkles"
        case .projects: return "folder"
        case .intelligence: return "brain.head.profile"
        case .reports: return "chart.bar"
        case .settings: return "gearshape"
        }
    }
}
