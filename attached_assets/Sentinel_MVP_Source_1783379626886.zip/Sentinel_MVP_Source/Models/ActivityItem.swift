import Foundation

struct ActivityItem: Identifiable, Hashable {
    let id = UUID()
    let timestamp: Date
    let message: String
    let category: Category

    enum Category: String, Hashable {
        case info, success, warning, error, scan
    }
}

extension ActivityItem.Category {
    var symbol: String {
        switch self {
        case .info: return "›"
        case .success: return "✓"
        case .warning: return "⚠"
        case .error: return "✕"
        case .scan: return "◦"
        }
    }
}
