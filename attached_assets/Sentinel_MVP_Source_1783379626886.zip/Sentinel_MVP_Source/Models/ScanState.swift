import Foundation

enum ScanState {
    case ready
    case scanning
    case analysing
    case complete
    case error
}
