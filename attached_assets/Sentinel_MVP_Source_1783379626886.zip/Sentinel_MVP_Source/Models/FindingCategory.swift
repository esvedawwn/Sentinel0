import Foundation

enum FindingCategory: String, CaseIterable, Identifiable {
    case emptyFolder = "Empty Folder"
    case zeroByteFile = "Zero-byte File"
    case adobeLock = "Adobe IDLK Lock"
    case googleLock = "Google Lock File"
    case installer = "Installer / Archive"
    case largeFile = "Large File"
    case brokenLink = "Broken Link"
    case unknown = "Unknown"

    var id: String { rawValue }
}
