# Sentinel Organizer MVP Source Kit

Drop-in SwiftUI MVP for your existing `SentinelOrganizer` macOS app.

## Features
- Sentinel design system
- Sidebar navigation
- Dashboard
- Live activity console
- Real filesystem scanning
- Safe preview mode
- Empty folder detection
- Zero-byte file detection
- Adobe `.idlk` lock detection
- Google `.locked` file detection
- Installer/archive detection
- Large file detection
- Findings table
- Reports screen
- Folder picker

## Important
This MVP does **not** delete, move, rename or modify files. It only scans and reports.

## Install
1. Unzip this folder.
2. In Xcode, create groups: Core, Utilities, Models, Managers, Services, Views.
3. Drag each `.swift` file into the matching group.
4. Tick **Copy items if needed**.
5. Tick **Target Membership → SentinelOrganizer** for every file.
6. Replace existing files with the included versions where names match.
7. Press `Command + B`.
8. Press `Command + R`.

## App Sandbox note
If scanner access is blocked, use **Choose Folders** inside the app, or temporarily disable **App Sandbox** during development.
